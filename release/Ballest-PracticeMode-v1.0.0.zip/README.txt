Ballest Practice Mode v1.0.0

RECOMMENDED:
Use Ballest-PracticeMode-Installer.exe from the GitHub Release. It installs
UE4SS automatically if needed.

MANUAL INSTALL:
1. Install a compatible UE4SS build for Ballest of Them All.
2. Open:
   Ballest\Binaries\Win64\ue4ss\Mods
3. Copy the included PracticeMode folder into Mods.
4. Launch Ballest.

The included PracticeMode\enabled.txt enables the mod without requiring you
to edit mods.txt manually.

Practice runs intentionally cannot submit leaderboard scores.
